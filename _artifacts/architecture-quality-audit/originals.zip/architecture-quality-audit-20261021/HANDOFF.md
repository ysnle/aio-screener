# 전체 코드베이스·품질 감사 — 최신 진행 인계

MODE: review | VERDICT: IN_PROGRESS / 재현된 문제 있음
REF: v58.52, `d36bb256ddf60468d6c7a134628053c5796be6be` (2026-10-21 KST 재개)

전체 전문 의미 검토 완료를 뜻하지 않는다. 파일별 미독·부분·동일 해시 재사용과 새 검토를 읽기 원장에서 구별한다. 제품 코드·버전·운영 데이터 수정, 커밋·푸시·배포는 이 감사에서 하지 않았다. 보고서와 격리 재현 자료만 작성한다. 다른 세션의 기존 dirty 변경은 이 작업 소유가 아니다.

## 현재 판단

native ESM, 순수 도메인 계산, 화면별 수명주기, CI가 검증한 SHA의 배포는 유지할 방향이다. 파일을 나누거나 미사용 모듈을 없앤 사실만으로 의미적 정확성이 좋아졌다고 판단할 수는 없다. 우선순위는 **결측·날짜·통화·입력 identity가 계층을 통과할 때 보존되는지, 그리고 QA가 그 실패를 실제로 잡는지**다. 전면 재작성이나 새 프레임워크 도입이 필요하다는 근거는 없다.

이전 원문 감사는 [v57.98 구조 인계](../architecture-quality-audit-20261018/HANDOFF.md), [v58.20 금융 검토](../architecture-quality-audit-20261019/FINANCIAL.md), [거시·시장 전문 검토](../architecture-quality-audit-20261019/MACRO-MARKET.md), [UI 전문 검토](../architecture-quality-audit-20261019/UI-PAGES.md), [legacy 읽기 경계](../architecture-quality-audit-20261019/LEGACY-DATA.md)에 보존했다. 이전 보고의 ‘현행’은 각 보고의 고정 REF에 한정한다.

## 재확인한 문제와 증거

최신 원시 실행은 [초기 실행 기록](./probe-runs-initial.json) 및 각 `*-result.json`에 저장했다. 실제 모듈과 최소 DOM/시간/파일 I/O seam을 이용한 격리 반례이며, 실제 공급자·라이브 발생 빈도의 증거는 아니다. 스크립트가 종료 코드 0인 것은 결함이 없다는 의미가 아니라 관찰을 정상 기록했다는 의미일 수 있다.

| 영역 | 관찰된 실패 | 근거·최소 보완 |
|---|---|---|
| 공유 시장 모델 | 금리 이력과 지수의 날짜가 달라지면 `null.yearPosition` 예외 | `market-reading-result.json`. 해당 축을 보류하고 나머지 모델을 유지하는 경계가 필요 |
| 금리 설명 | 실질금리 -20bp와 +20bp에 동일한 ‘상승 부담 지속’ 설명 | 같은 파일의 반대 부호 대조. 원인의 종류와 움직임 방향을 함께 분기 |
| 손익 표시 | USD 현재가100과 KRW 원가140000을 직접 빼 -$139,900 표시 | `reproduce-ui-pages.mjs`. 포트폴리오와 종목 화면이 같은 환산·보류 계약을 사용 |
| 가격 정규화 | `_valuationPrice`가 사라져 유효 예상 PER20이 null | `domain-contract-result.json`. 생산→provider→정규화→소비 필드 보존 |
| 스크리너 | 앞 5개 순위가 같으면 아래 행의 지표가 바뀌어도 요약 갱신 안 됨 | UI probe: 실제 도메인 건강도100%→50%, 렌더1회. 요약 입력 전체에 갱신 identity 결속 |
| 조건 실행 기록 | NOT 내부 가격40→60에 결과는 달라지나 calculationInputId 동일 | `domain-contract-result.json`. evaluator와 identity collector의 AST 노드 처리 일치 |
| 통계 | 변동 없는 두 팩터의 상관을0, 독립 정보 수2로 게시 | 같은 결과의 정상 대조 rho1/effective1. 정의 불가와 무상관을 구별 |
| 시각화 | 빈 이익/매출과 실제0을 동일한0%로 렌더 | `answer-visual-result.json`. null을0으로 바꾸기 전 입력 계약 보존 |
| 상대 차트 | 날짜가 하루 다른 두 계열을 인덱스로 겹치고 첫 계열 기간만 표기 | 같은 파일. 공통 날짜 정렬 또는 차이 명시 |
| 차트 도구 실패 | 간이 renderer가 null을 실제0과 같은 점으로 그림 | `chart-fallback-result.json`. 원래 날짜 위치와 결측 gap 유지 |
| 리서치 이동 | 산업 지도 관련 분석 노트/개념 클릭 뒤 선택 상태가 지워짐 | 최신 격리 probe와 v58.50 실제 브라우저. 목적 노트 대신 기본 노트 표시 |
| 교육 레슨 | D6의 D2/D3 선수 레슨이 정규식 때문에 사라짐 | UI probe. 실제 prerequisite ID 파싱 확인 |
| 비동기 대상 | 관심목록 A에서 추가 요청 후 B로 전환하면 B에 저장 | `reproduce-boundaries.mjs`. 요청 시작 시 대상 ID 고정 |
| 검색 | 입력 clear/reset 후 늦은 응답이 후보를 다시 채움 | `search-race-result.json`. clear도 요청 세대 취소에 포함 |
| SW | 활성화 시 같은 origin의 타 앱 이름 캐시까지 삭제 | `sw-activation-result.json`. 현재 AIO 캐시 유지 대조 포함. 실존 타 앱 피해는 미측정 |
| QA 수집 | JS 디렉터리를 빠뜨린 CSP gate가0/450 PASS | `csp-coverage-result.json`: 현재400 JS 중 추가210 innerHTML 할당 미수집. 210개 XSS라는 뜻은 아님 |
| QA 판정 | 숨겨진 텍스트를 확인 성공으로 인정 | `verification-helper-result.json`. 화면에 보이는 값과 assertion 조건을 일치 |
| QA 라이브 gate | 0/0 또는16/16 선언+빈 quotes 응답을 완전 성공으로 인정 | `gate-oracle-result.json`. 실제 항목·필수 집합 검증; 실제 Worker 장애로 단정하지 않음 |
| QA 쓰기 부작용 | parity 실패 시 virtual manifest가 바뀐 채 남음 | 같은 파일. 실제 gate를 작업트리에서 실행하지 않았음. check 모드 또는 격리 비교 필요 |
| 한국 스트레스 | 유효20거래일 창1개인데 전체 행 수로 표본 하한 통과 | `session-sample-result.json`. 필터 후 유효 비중첩 사례 수로 하한 판정 |

QA cache 재현은 삭제된 knowledge-repository gate 대신 현행 data-continuity gate로 갱신했다. 실제 fingerprint 함수에서 price-factors 의존 파일 변경은 hash를 바꾸지 않고 gate 본문 변경은 바꾼다. 정적 closure 누락 gate는 현재20개이며, 20개의 제품 결함 수로 세지 않는다. `cache-identity-result.json`, `cache-input-review.json` 참조.

## 브라우저와 라이브

v58.50 로컬에서 8개 주 메뉴를 모두 열었고, 시장/거시/종목/리서치 하위 탭, 용어 검색·Escape, AI 입력(전송 없음)을 기록했다. 이것은 모든 조작·오류 상태를 통과했다는 인증이 아니다. 초기 비동기 로딩이 남은 캡처도 있어 최종 성공과 구별한다. [원시 브라우저 기록](../architecture-quality-audit-20261020/browser-events.json).

실제 결함 두 건: 한국 장중 테마의 시세 미수신 상세가 +0.00%·상승0%·‘하락0개가 상승0개보다 많다/건강도 취약’으로 표시됨. 산업 지도 DRAM·HBM에서 ‘HBM과 광 인터커넥트의 역할 분담’을 누르면 기본 ‘산술평균 수익률과 실현 복리 수익률의 괴리’ 노트가 열림. 원시 aria와 스크린샷은20폴더에 있다.

2026-10-21에는 실제 Pages에서 v58.52를 확인하고 휴대폰390×844까지 점검을 재개했다. 라이브 화면 버전 표시는 확인했지만, 이 사실만으로 로컬 HEAD와 모든 배포 bytes 일치를 인증하지 않는다. [이번 브라우저 기록](./browser-events.json). AI 메시지를 전송하거나 직접 유료 API를 호출하지 않았으며, 뉴스 화면의 자동 번역 내부 과금 여부는 검증하지 않았다.

## 해소·제외와 진행 중 범위

- 미사용 `src/domain/screener/regime.js`가 삭제됐다. 이전 hold 시계 잠복 문제는 현행 실행 결함에서 제외한다.
- benchmark의 누락 거래일 비교는 현재 공통 session helper를 사용한다. 완전/누락 이력의63거래일 수익률 대조가 일치하므로 옛 후보를 재등록하지 않는다.
- 원문 파일 수833, split-line slots223148. JS781개 구문 분석 오류0, 알려진 bootstrap 연결385개/정적 boot272개, 정적 순환0. 원문 정적 boot2,767,190 bytes는 배포 gzip/브라우저 전송량이 아니다.
- 현재 UI 변경분, 금융·거시 변경분/새 모듈, legacy aio-data 잔여 전문 읽기를 독립 검토자가 진행 중이다. 동일 모델의 새 맥락 검토이므로 독립성은 limited다.
- 다수 CI/도구/legacy core·chat·전체 index HTML/CSS 의미 검토 및 모든 정책 원장 최신 재검토가 남아 있다. 자동 gate PASS나 파일 hash 일치로 이 범위를 완독 처리하지 않는다.

## 리팩토링·정책에 대한 판단

1. 결측을 보류하고 날짜·출처를 밝히며 단위가 다른 값은 계산하지 않는 정책은 유지한다. 다만 정책이 옳아도 실제 상세 renderer와 정규화에서 이를 잃고 있어 경계 수정이 우선이다.
2. Actions 생산 경계, Worker Secrets와 원자 월예산, 명시적 배포 승인은 운영 규모에 맞는다. 예약 장부의 격리 동시성 검증은 통과했으나 실제 청구서와 일치한다는 증거는 아니다.
3. 조건 충족 개수·참고 순위·관례 임계값은 관찰 분류로 한정한다. 숫자를 공개했다는 사실이 예측력을 보장하지 않는다. 사용자 가치와 재현된 오판 사례로 기준을 조정하고, 새 합성 점수를 만들지 않는 편이 낫다.
4. 기존 설명 규칙을 더 긴 문서·문자열 pin으로 늘리기보다, 반대 부호·부분 입력·오래된 날짜·다른 통화의 작은 행동 반례를 기존 gate에 넣는 것이 효과적이다.
5. 공개 SaaS 절차나 형식적 인증을 가족·지인용 무료 도구의 배포 장벽으로 새로 요구하지 않는다. 비밀·공유 예산·숫자와 날짜의 정직성·공개 저장소 경계는 유지한다.
6. 화면은 결론→차트→근거 원칙을 다시 적용할 필요가 있다. 실제 휴대폰 첫 화면은 긴 해설이 대부분을 차지한다. 요약 한 줄과 대표 그림을 먼저 놓고 기존 상세는 펼침으로 옮기는 안을 제안한다. 기능 통합·삭제는 승인 전 시행하지 않는다.

다음 인계 갱신에는 독립 검토 결과의 재현·반증과 현재 파일별 완료/미검토 수를 합산한다. 배포·전체 QA 인증 없이 완료를 선언하지 않는다.
